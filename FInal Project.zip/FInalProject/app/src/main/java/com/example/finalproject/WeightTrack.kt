package com.example.finalproject

class WeightTrack {
    var id: Int = 0
    var weight: Int = 0
    var date: String = "01/01/2020"

    constructor(weight: Int, date: String)
    {
        this.id = id
        this.weight = weight
        this.date = date
    }

}